<a id="top"></a>

<p style="font-size: 24px;"><img src="./qct-icons/transform-logo.svg" style="margin-right: 15px; vertical-align: middle;"></img><b>Code Transformation Summary by Amazon Q </b></p>
<p><img src="./qct-icons/transform-variables-dark.svg" style="margin-bottom: 1px; vertical-align: middle;"></img> Lines of code in your application: 1098 <p>
<p><img src="./qct-icons/transform-clock-dark.svg" style="margin-bottom: 1px; vertical-align: middle;"></img> Transformation duration: 17 min(s) <p>
<p><img src="./qct-icons/transform-dependencies-dark.svg" style="margin-bottom: 1px; vertical-align: middle;"></img> Planned dependencies replaced: 3 of 5 <p>
<p><img src="./qct-icons/transform-dependencyAnalyzer-dark.svg" style="margin-bottom: 1px; vertical-align: middle;"></img> Additional dependencies added: 3 <p>
<p><img src="./qct-icons/transform-smartStepInto-dark.svg" style="margin-bottom: 1px; vertical-align: middle;"></img> Planned deprecated code instances replaced: 0 of 0 <p>
<p><img src="./qct-icons/transform-listFiles-dark.svg" style="margin-bottom: 1px; vertical-align: middle;"></img> Files changed: 14 <p>
<p><img src="./qct-icons/transform-build-dark.svg" style="margin-bottom: 1px; vertical-align: middle;"></img> Build status in Java 17: <span style="color: #00CC00">SUCCEEDED</span> <p>

### Table of Contents

1. <a href="#build-log-summary">Build log summary</a> 
1. <a href="#planned-dependencies-replaced">Planned dependencies replaced</a> 
1. <a href="#additional-dependencies-added">Additional dependencies added</a> 
1. <a href="#deprecated-code-replaced">Deprecated code replaced</a> 
1. <a href="#other-changes">Other changes</a> 
1. <a href="#all-files-changed">All files changed</a> 
1. <a href="#next-steps">Next steps</a> 


### Build log summary <a style="float:right; font-size: 14px;" href="#top">Scroll to top</a><a id="build-log-summary"></a>

Amazon Q successfully built the upgraded code in Java 17. Here is a relevant snippet from the build log. To view the full build log, open [`buildCommandOutput.log`](./buildCommandOutput.log)

```
The Maven build compiled 35 source files and 4 test source files using Java 17 after cleaning previous build artifacts. One deprecation warning was emitted during compilation. The build completed successfully in 7 seconds.
```


### Planned dependencies replaced <a style="float:right; font-size: 14px;" href="#top">Scroll to top</a><a id="planned-dependencies-replaced"></a>

Amazon Q updated the following dependencies that it identified in the transformation plan

| Dependency | Action | Previous version in Java 8 | Current version in Java 17 |
|--------------|--------|--------|--------|
| `org.apache.maven.plugins:maven-checkstyle-plugin` | Updated | 3.1.0 | 3.6.0 |
| `org.jacoco:jacoco-maven-plugin` | Updated | 0.8.3 | 0.8.12 |
| `org.springframework.boot:spring-boot-starter-parent` | Updated | 2.1.4.RELEASE | 3.3.5 |

### Additional dependencies added <a style="float:right; font-size: 14px;" href="#top">Scroll to top</a><a id="additional-dependencies-added"></a>

Amazon Q updated the following additional dependencies during the upgrade

| Dependency | Action | Previous version in Java 8 | Current version in Java 17 |
|--------------|--------|--------|--------|
| `com.amazonaws:aws-java-sdk-dynamodb` | Updated | 1.11.86 | 1.12.543 |
| `com.google.code.gson:gson` | Updated | 2.8.5 | - |
| `org.projectlombok:lombok` | Updated | 1.18.6 | - |

### Deprecated code replaced <a style="float:right; font-size: 14px;" href="#top">Scroll to top</a><a id="deprecated-code-replaced"></a>

Amazon Q replaced the following instances of deprecated code. An instance with 0 files
changed indicates Amazon Q wasn't able to replace the deprecated code.

| Deprecated code | Files changed |
|----------------|----------------|


### Other changes <a style="float:right; font-size: 14px;" href="#top">Scroll to top</a><a id="other-changes"></a>



### All files changed <a style="float:right; font-size: 14px;" href="#top">Scroll to top</a><a id="all-files-changed"></a>

| File | Action |
|----------------|--------|
| [.mvn/wrapper/maven-wrapper.properties](../.mvn/wrapper/maven-wrapper.properties) | Updated |
| [mvnw](../mvnw) | Updated |
| [mvnw.cmd](../mvnw.cmd) | Updated |
| [pom.xml](../pom.xml) | Updated |
| [src/main/java/com/bhoruka/bloodbank/configuration/DynamoDbConfig.java](../src/main/java/com/bhoruka/bloodbank/configuration/DynamoDbConfig.java) | Updated |
| [src/main/java/com/bhoruka/bloodbank/configuration/WebSecurityConfig.java](../src/main/java/com/bhoruka/bloodbank/configuration/WebSecurityConfig.java) | Updated |
| [src/main/java/com/bhoruka/bloodbank/dao/CampDao.java](../src/main/java/com/bhoruka/bloodbank/dao/CampDao.java) | Updated |
| [src/main/java/com/bhoruka/bloodbank/model/CampModel.java](../src/main/java/com/bhoruka/bloodbank/model/CampModel.java) | Updated |
| [src/main/java/com/bhoruka/bloodbank/service/CampService.java](../src/main/java/com/bhoruka/bloodbank/service/CampService.java) | Updated |
| [src/main/java/com/bhoruka/bloodbank/web/CampController.java](../src/main/java/com/bhoruka/bloodbank/web/CampController.java) | Updated |
| [src/main/resources/application.properties](../src/main/resources/application.properties) | Updated |
| [src/test/java/com/bhoruka/bloodbank/dao/CampDaoTest.java](../src/test/java/com/bhoruka/bloodbank/dao/CampDaoTest.java) | Updated |
| [src/test/java/com/bhoruka/bloodbank/service/CampServiceTest.java](../src/test/java/com/bhoruka/bloodbank/service/CampServiceTest.java) | Updated |
| [src/test/java/com/bhoruka/bloodbank/web/CampControllerTest.java](../src/test/java/com/bhoruka/bloodbank/web/CampControllerTest.java) | Updated |

### Next steps <a style="float:right; font-size: 14px;" href="#top">Scroll to top</a><a id="next-steps"></a>

1. Please review and accept the code changes using the diff viewer.If you are using a Private Repository, please ensure that updated dependencies are available.
1. 
1. In order to successfully verify these changes on your machine, you will need to change your project to Java 17. We verified the changes using [Amazon Corretto Java 17](https://docs.aws.amazon.com/corretto/latest/corretto-17-ug/what-is-corretto-17.html
) build environment.
1. If this project uses Maven CheckStyle, Enforcer, FindBugs or SpotBugs plugins, Q Code Transformation will disable those plugins when we build the project to verify proposed upgrades.